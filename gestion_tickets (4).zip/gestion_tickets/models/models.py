# -*- coding: utf-8 -*-

from odoo import models, fields, api

class TestModel(models.Model):
    _name = "test.model"
    _description = "Test Model"

# class c:\users\clara\documents\odoo\mymodules\firstmodule(models.Model):
#     _name = 'c:\users\clara\documents\odoo\mymodules\firstmodule.c:\users\clara\documents\odoo\mymodules\firstmodule'
#     _description = 'c:\users\clara\documents\odoo\mymodules\firstmodule.c:\users\clara\documents\odoo\mymodules\firstmodule'

#     name = fields.Char()
#     value = fields.Integer()
#     value2 = fields.Float(compute="_value_pc", store=True)
#     description = fields.Text()
#
#     @api.depends('value')
#     def _value_pc(self):
#         for record in self:
#             record.value2 = float(record.value) / 100
