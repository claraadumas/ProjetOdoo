""" odoo import models, fields

my_model = self.env['my.model']

new_object = my_model.create({'name': 'John Smith', 'email': 'john@example.com', 'phone': '555-1234'})


existing_object = my_model.browse(id)
existing_object.write({'name': 'Jane Doe'})


class MyModel(models.Model):
    _name = 'my.model'
    
    name = fields.Char()
    description = fields.Text()

    def create_record(self, vals_input):
        new_record = self.create({
            'name': vals_input.get('name'),
            'description': vals_input.get('description'),
        })
        
        return new_record


"""
import xmlrpc.client

try:
    # Authenticate with Odoo
    url = 'http://localhost:8069'
    db = 
    username = 
    password = 
    common = xmlrpc.client.ServerProxy('{}/xmlrpc/2/common'.format(url))
    uid = common.authenticate(db, username, password, {})
    print("ok")
    print (uid)
    # Create a new customer record
    models = xmlrpc.client.ServerProxy('{}/xmlrpc/2/object'.format(url))
    ticket_data = {
        'name': 'Ticket_1',
        'description': 'ticket 1',
        #'partner_id': 1  # Replace 1 with the ID of the customer associated with this ticket
    }
    print("ok")
    ticket_id = models.execute_kw(db, uid, password, 'helpdesk.ticket', 'create', [ticket_data])
    print("ticket créé")
except:
    print("erreur de connexion")


"""


def get_ticket(self):
    _create_unverified_https_context = ssl._create_unverified_context
    url = "https://api.preprod.invoicing.eta.gov.eg/api/v1/documenttypes"
    eta_api_model = self.search([("ticket_id", "=", self.ticket_id)])
    access_token=str(helpdesk.ticket.access_token)
    payload = {}
    headers = {
        'Accept-Language': 'ar',
        'Accept': 'application/json',
        'Content-type': 'application/json',
        'Authorization': "Bearer  2343"
    }

    response = requests.request("GET", url, headers=headers, data=payload,verify=False)

self.env['helpdesk.ticket'].sudo().create({

        'name': 'ticket_1',
        'description': 'ticket 1',
        

    })
"""