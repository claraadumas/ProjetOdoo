# -*- coding: utf-8 -*-
# from odoo import http


# class C:\users\clara\documents\odoo\mymodules\firstmodule(http.Controller):
#     @http.route('/c:\users\clara\documents\odoo\mymodules\firstmodule/c:\users\clara\documents\odoo\mymodules\firstmodule', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/c:\users\clara\documents\odoo\mymodules\firstmodule/c:\users\clara\documents\odoo\mymodules\firstmodule/objects', auth='public')
#     def list(self, **kw):
#         return http.request.render('c:\users\clara\documents\odoo\mymodules\firstmodule.listing', {
#             'root': '/c:\users\clara\documents\odoo\mymodules\firstmodule/c:\users\clara\documents\odoo\mymodules\firstmodule',
#             'objects': http.request.env['c:\users\clara\documents\odoo\mymodules\firstmodule.c:\users\clara\documents\odoo\mymodules\firstmodule'].search([]),
#         })

#     @http.route('/c:\users\clara\documents\odoo\mymodules\firstmodule/c:\users\clara\documents\odoo\mymodules\firstmodule/objects/<model("c:\users\clara\documents\odoo\mymodules\firstmodule.c:\users\clara\documents\odoo\mymodules\firstmodule"):obj>', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('c:\users\clara\documents\odoo\mymodules\firstmodule.object', {
#             'object': obj
#         })
"""class MyController(http.Controller):

    @http.route('/gestion_ticket/get_ticket', auth='public', type='http', methods=['GET'])
    def get_ticket(self, **kw):
        #record_id = kw.get('id')
        record = http.request.env['gestion_ticket.model'].browse(int(record_id))
        data = {
            'id': record.id,
            'name': record.name,
            'description': record.description,
            # Ajoutez les autres informations dont vous avez besoin
        }
        return http.request.make_response(json.dumps(data), headers=[('Content-Type', 'application/json')])
"""